from filter import filter_string


def test_1():
    assert(filter_string("Hello, my name is Mr O'Toole.") == ",'.")


def test_2():
    assert(filter_string("0")) == ValueError


def test_3():
    assert(filter_string("Hello, world.") == ",'.")

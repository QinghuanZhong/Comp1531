'''
Tests
'''
from brooms import send_message, get_messages, clear, get_users, add_user

def test_simple():
    clear()
    add_user("Jake")
    assert(get_users() == {"users":["Jake"]})
    add_user("Hayden")
    assert(get_users() == {"users":["Hayden", "Jake"]})
    send_message("Jake", "Hayden", "Hello!")
    send_message("Jake", "Hayden", "Goodbye!")
    assert get_messages() == {
        "messages": [
            {"from": "Jake", "to": "Hayden", "message": "Hello!"},
            {"from": "Jake", "to": "Hayden", "message": "Goodbye!"},
        ]
    }

# Write your tests here

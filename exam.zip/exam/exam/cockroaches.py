def decontaminate(filenames):
    pass

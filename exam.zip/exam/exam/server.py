'''
The flask server wrapper

All endpoints return JSON as output.
All POST requests pass parameters through JSON instead of Form.
'''
from json import dumps
from flask import Flask, request
from brooms import *
import brooms

APP = Flask(__name__)

'''
Endpoint: '/users'
Method: GET
Parameters: ()
Output: { "users": [ ... list of strings ...] }

Returns a list of all the users as a list of strings.
'''
# Write this endpoint here


@APP.route("/users", methods=['GET'])
def users():
    data = request.get_json()

    add_user()

    return dumps({})


'''
Endpoint: '/users'
Method: POST
Parameters: ( name: string )
Output: {}

Adds a user to the room/broom.
'''
# Write the endpoint here


'''
Endpoint: '/message'
Method: GET
Parameters: ()
Output: { "messages": [ { "from" : string, "to" : string, "message" : string } ] }

Returns a list of all the messages sent, who they came from, and who they are going to.
'''
# Write the endpoint here


'''
Endpoint: '/message'
Method: POST
Parameters: (user_from: string, user_to: string, message: string)
Output: {}

Sends a message from user "user_from" to user "user_to". All three parameters are strings.
'''
# Write the endpoint here


if __name__ == '__main__':
    # If you are running on VLAB and there is a port in use error,
    # you may need to change the port from 8080 to something else.
    #
    # REMEMBER TO SET THE PORT BACK TO 8080 BEFORE SUBMITTING!
    #
    APP.run(debug=True, port=8080)

def suffix_message(function):
    def wrapper(*args, **kwargs):  # - args 'The weather is ' + weather + ' today'
        # TODO: Part A
        message = (args[0] + args[1] + args[2] + 'Suffix:' + args[1])

        return function()
    return wrapper


@suffix_message
def greet(person, greeting):
    return f'Hello {person}! {greeting}'


@suffix_message
def show_weather(weather):
    return 'The weather is ' + weather + ' today'


@suffix_message
def hello():
    return 'Hello'


@suffix_message
def side_effects_only(message):
    print(f'{message}! This function only has side effects.')

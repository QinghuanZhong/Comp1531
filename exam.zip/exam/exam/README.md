Please note: If you are looking at this repo before the exam starts, __you will need to wait until exam starts to view the spec link below.__
# [See exam spec here (not viewable until exam's live).](https://gitlab.cse.unsw.edu.au/COMP1531/22T1/exam-spec)

# Resources
* [ **Python Cheat Sheet**](https://www.pythoncheatsheet.org/)
* [**Python 3.7 Docs**](https://docs.python.org/3.7/library/index.html)


## HTTP Test Client

You will need to use a HTTP test client for the COMP1531 exam. If you are using VLAB you may need to remove the Postman Chromium application and re-add it for it to work. To do this:

1. Open chromium in TigerVNC
2. Install Postman Chromium app [by visting this URL in VLAB](https://chrome.google.com/webstore/detail/postman/fhbjgbiflinjbdggehcddcbncdddomop/related?hl=en). You can also use any other HTTP client of your choice.
2. Launch Postman app
4. If you are having issues launching postman chromium app, remove the postman chromium app by clicking apps, then right-clicking Postman and removing the app, then repeating steps 2 onwards.

    <img src='apps.png' align='center'/>
    <img src='remove.png' align='center'/>

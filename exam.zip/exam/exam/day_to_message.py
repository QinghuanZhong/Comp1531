from calendar import weekday
from datetime import date


def day_to_message(d):
    if (d == "monday" or d == "Monday"):
        return "It's Monday!"

    elif (d == "tuesday" or d == "Tuesday"):
        return "It's Tuesday! Exam DAY"

    elif (d == "wednesday" or d == "Wednesday"):
        return "it's the middle of the work week!"

    elif (d == "thursday" or d == "Thursday"):
        return "Almost friday..."

    elif (d == "friday" or d == "Friday"):
        return "Rebecca who?"

    elif (d == "saturday" or d == "Saturday"):
        return "yay weekend!"

    elif (d == "sunday" or d == "Sunday"):
        return "almost monday :("


if __name__ == '__main__':
    d = input("Enter the day of the week")

    if (d == "monday" or d == "Monday"):
        d = "monday"

    elif (d == "tuesday" or d == "Tuesday"):
        d = "tuesday"

    elif (d == "wednesday" or d == "Wednesday"):
        d = "wednesday"

    elif (d == "thursday" or d == "thursday"):
        d = "thursday"

    elif (d == "friday" or d == "friday"):
        d = "friday"

    elif (d == "saturday" or d == "Saturday"):
        d = "saturday"

    elif (d == "sunday" or d == "sunday"):
        d = "sunday"

    else:
        exit()

    print(day_to_message(d))

import string
# from filter import filter_string


def filter_string(inp):
    '''
    filters the string according to the instructions above.
    Full stops (.)
    Commas (,)
    Quotation marks (single and double) (',")
    Semicolons (;)
    Question marks (?)
    Exclamation marks (!)
    filter_string("Hello, my name is Mr O'Toole.") == ",'."
    '''
    if inp is int:
        raise ValueError

    ch = filter(lambda c: c in string.punctuation, inp)
    ch_list = list(ch)
    # print(str)
    # print(string.punctuation)

    return ch_list

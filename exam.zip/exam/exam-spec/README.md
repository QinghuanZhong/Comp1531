# COMP1531 Final Exam 2022 Term 1

For this exam you are provided with this public repostory containing the questions being asked. You will then also have your own **[personal exam repository](https://cgi.cse.unsw.edu.au/~cs1531/redirect/?path=COMP1531/22T1/students/_/exam)** where you actually answer and submit these questions to.

If you are seeking information not provided in this file, check the [COMP1531 Exam Brief page](https://webcms3.cse.unsw.edu.au/COMP1531/22T1/resources/70618). If your question is still unanswered, follow the "Communication & Help during the exam" instructions at that link.

## Change Log
* Clarifications to punctuation in Question 10

## WARNING

This applies to all students completing the COMP1531 22T1 exam.

* This exam is an individual assessment. Any attempt to communicate with other people (both other students in this course and outside persons) about the contents of this exam will be treated as academic misconduct and may result in you failing this course. This applies to everyone during the exam time. To avoid any doubt about your behaviour during the exam, cease all communication with other students for that time.
* From Thursday the 6th of May onward, you are only allowed to discuss the exam with students who have themselves also completed the exam, and it's your responsibility to check if they have.
* Your zpass should not be disclosed to any other person. If you have disclosed your zpass, you should change it immediately.
* Do not place your exam work in any location accessible to any other person. This includes services such as Dropbox and Github.
* If another student in the course makes any sort of contact with you during the exam, or you're aware of any instances of other students breaching the conditions above, you are required to email cs1531@cse.unsw.edu.au with details of the interaction.

## Part 1. Cloning your repository

Please clone your **[personal exam repository](https://cgi.cse.unsw.edu.au/~cs1531/redirect/?path=COMP1531/22T1/students/_/exam)**.

## Part 2. Questions - Short Answer (25%)

For each of these questions, write the answer in the relevant text file in the repository you just cloned in step 1.

<br />

### Question 1 (2 marks)

In your personal exam repository, answer this question in `q1.txt`.

Consider this statement:
 > The team has just returned from the client's offices where they have been interviewing and catching up with users on how the latest release has gone for them

<b>Q. If you were told this statement, what part of the SDLC would you think this fits into? Justify your response.</b>

<br />

### Question 2 (1 marks)

In your personal exam repository, answer this question in `q2.txt`.

A team member sent you a message on Teams that said the following about their work:
> I have built a function that parses a date (e.g. "2021-10-10") by breaking up the date into components based on the dash, then converting each of the 3 components into a number of seconds since 1st January 1970, and returning that value. I think it's a really important and necessary function, though others tell me it's not easy to understand.

<b>Q. Would you consider this an example of accidental complexity or essential complexity? Justify your response</b>

<br />

### Question 3 (2 marks)

In your personal exam repository, answer this question in `q3.txt`.

Consider this requirement:
> I really hate how slow the Gitlab pipelines can be when we're close to deadlines. I understand that lots of people are cramming just like me, and I understand that I could have planned my time better, but that won't stop me being annoyed, you know? ?? The biggest issue I have is that when the pipelines are slow, even though I could run things locally, I don't have the confidence that my local code will work on CSE systems."

<b>Q. Write a user story to capture the above requirement.</b>

## The next three questions relate to the following scenario.

UNSW has decided to create a robot soccer team known as the Bobocup Champions. This team consists of engineers who design and write software to run on small humanoid robots. There is a competition coming up in July 2022, and you're one of the team members on this team trying to build the best robots in the world.

### Question 4 (2 marks)

In your personal exam repository, answer this question in `q4.txt`.

<b>Q. Which of the following would constitute an Agile approach in trying to design and write software to become the Bobocup Champions?</b> There may be multiple answers. Write any relevant answers as `a`, `b`, `c`, `d`, or `e` in the text file.

<ol type='a'>
    <li>Ensuring that you have a 6 month plan of all the programming you want to do before you begin development.</li>
    <li>Focusing on ensuring the best testing pipelines are setup as a priority over how your team members feel about the testing processes.</li>
    <li>Producing a simple tested prototype that isn't perfect but helps you learn, rather than waiting months until it is perfect.</li>
    <li>Dedicating one engineer's entire role to writing a manual documenting how the robots works.</li>
    <li>Having short meetings at least twice a week.</li>
</ol>

<br />

### Question 5 (2 marks)

In your personal exam repository, answer this question in `q5.txt`.

Currently, the team has been using Google Drive to collaborate on their code. They are looking to move to use git and GitLab instead. 

<b>Q. List three benefits of using git/GitLab to manage the team's codebase. </b>

### Question 6 (1 mark)

In your personal exam repository, answer this question in `q6.txt`.

Consider the following situation regarding how the Bobocup team structures their use of branches:

<img src='branch.png' align='center'/>

> Each new feature should reside in its own branch, which can be pushed to the central repository for backup/collaboration. When a feature is complete, it gets merged back into master. Features should never be written directly on the master branch.

<b>Q. Describe one benefit of this process.</b>

<br />

### Question 7 (3 marks)

In your personal exam repository, answer this question in `q7.txt`.

<b>Q. In the context of software safety, what does EAFP stand for? What is an example of a language that uses this principle, and what is an example of that principle being applied?</b>

### Question 8 (2 marks)

In your personal exam repository, answer this question in `q8.txt`.

<b>Q. Describe one benefit and one limitation of code coverage measurements (such as Python's `coverage` command)  </b>

### Question 9 (10 marks)

In your personal exam repository, answer this question in `q9.txt`.

Seperate your answers to Parts A and B with a blank line.

#### Part A (3 marks)

Below is some code used by COMP1531 staff to extract marks from a spreadsheet.

```python
import gspread
google_sheet = gspread.service_account('creds.json')
sheet = gc.open('COMP1531 22T1 Marking')

marks1 = sheet.worksheets()[1]
marks2 = sheet.worksheets('marks')
```

`marks1` accesses the marks tab of the spreadsheet by reading list of sheets, and accessing the item at index 1 in the list (see below).

<img src="marks.png" />

`marks2` accesses the relevant tab by using a method of the sheet object to lookup the marks tab by name.

Out of `marks1` or `marks2`, which would be considered more robust? Why? You do not need to think about performance at all in this question.

#### Part B (7 marks)

Consider the following code that handles user registration.

```python
from helpers import password_score
import random
import hashlib

usernames = []
passwords = []

def get_random_number(x, y):
    # Gets a random number between two numbers
    return random.randint(x, y)

def add_user(username, password):
    '''
    Adds a user to our data store.
    If the username matches an existing username, it adds numbers to avoid having the same username

    Returns 1 the password not strong enough
    Returns 0 in success case, because I just took COMP1511 and coding in Python is just like C right?
    '''

    if password_score(password) < 5:
        return 1

    for x in range(len(usernames)):
        if usernames[x] == username:
            username += str(get_random_number(1, 10))

            # Loop through again to check we haven't changed it to the same username
            for x in range(len(usernames)):
                if usernames[x] == username:
                    username += str(get_random_number(1, 10))

    # Hash the password
    hashedPassword = hashlib.sha256(password.encode()).hexdigest()

    usernames.append(username)
    passwords.append(hashedPassword)

    return 0

def does_user_exist(username):
    # Checks if a username exists in the list of usernames
    return len(list(filter(usernames, lambda u_name: u_name == username))) > 0
```

<ol type="i">
    <li>Run pylint on this code. What is the <code>pylint</code> score for this code? State <b>three</b> different style issues in the code that <code>pylint</code> has detected. We have provided the code for you in <code>code_review_q9.py</code> (2 marks)</li>
    <li>Describe <b>two</b> elements of the code that demonstrate robust/good coding practices. Copy and paste the lines of code you are referring to in your answer. (2 marks)</li>
    <li>State and explain <b>three</b> elements of the code that demonstrate poor design or poor pythonic coding practices, or are code smells. Your answer cannot include anything <code>pylint</code> has detected. (3 marks)</li>
</ol>

## Part 3. Questions - Programming Questions (75%)

These questions involve you writing Python implementations, and in some cases writing Python tests with `pytest`.

<br />

### Question 10 (5 marks)

In your personal exam repository, answer this question in `filter.py` and `filter_test.py`.

Write a function that takes in a string of ascii characters and punctuation, and returns a filtered version of that string after all non-punctuation characters have been removed. For this problem, punctuation *only* includes:
 * Full stops (.)
 * Commas (,)
 * Quotation marks (single and double) (',")
 * Semicolons (;)
 * Question marks (?)
 * Exclamation marks (!)

For example:

```python
filter_string("Hello, my name is Mr O'Toole.") == ",'."
```

Complete the function `filter_string` in `filter.py` that filters the string according to the instructions above.

Write tests for this function in the file `filter_test.py`.

If the string passed in contains any numbers, your function should raise a `ValueError` (the message is optional).

You can assume all strings passed in contain only ASCII characters and the length is larger than 0.

To run your tests you can run `pytest filter_test.py`.

To run coverage you can run `coverage run -m pytest filter_test.py` followed by `coverage report`.

You will receive 60% of your marks from the correctness of your implementation, 15% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

<br />

### Question 11 (10 marks)

In `day_to_message.py` there is a fully-functional Python program which allows the user to enter a day of the week, and prints out a message depending on the day that was input by the user. Your task is to refactor the program to adhere to good programming principles, including:

* DRY - Don't Repeat Yourself.
* KISS - Keep It Simple Stupid.
* Pythonic - Use appropriate Pythonic language tools to solve the problem more expressively.
* Python Documentation

There is no single solution for this question, and the solution is partially manually marked. We are testing that you can utilise the concepts taught in COMP1531 to identify, understand and refactor Python programs to adhere to good programming standards.

Functionality should remain the same, autotests included in `day_to_message.py` can be used to ensure you did not change or break the functionality of the program. There are no additional hidden autotests used for marking. 3 marks are awarded for maintaining passing autotests, 7 marks for code quality and style.


### Question 12 (10 marks)

In your personal exam repository, answer this question in `cockroaches.py` and `cockroaches_test.py`.

You find that your house is infested with cockroaches. One day it becomes too much and you decide to keep a tally of where the cockroaches are each day. On Monday, Tuesday and Wednesday you write the following files:

<b>monday.txt</b>:
```text
kitchen
bathroom
attic
```

<b>tuesday.txt</b>:
```text
backyard
kitchen
bedroom
attic
```

<b>wednesday.txt</b>:
```text
attic
bathroom
```

Write a function `decontaminate(filenames)` in `cockroaches.py` which takes a list of filenames and counts the frequency of sightings in each file. Each sighting is just a string separated by a new line. The function returns a dictionary (frequency count) of sightings.

The above example would return the following dictionary, such that the assert is successful:

```python
assert(decontaminate(['monday.txt', 'tuesday.txt', 'wednesday.txt']) == { 'kitchen': 2, 'attic': 3, 'bathroom': 2, 'bedroom': 1, 'backyard': 1 })
```

Please note:
 * We expect your tests to create the files and populate it with sample data using the `generate_files` function provided. Do not hard code test `.txt` files into your repo because otherwise all of your tests will fail when we mark you;
 * You can assume the files only contain ascii characters.
 * You can assume the same room will never be listed more than once in the same text file for any given day.

To run your tests you can run `pytest cockroaches_test.py`.

To run coverage you can run `coverage run -m pytest cockroaches_test.py` followed by `coverage report`.

You will receive 50% of your marks from the correctness of your implementation, 25% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

<br />

### Question 13 (30 marks)

Having dominated the asynchronous communication market with UNSW Seams, UNSW has decided to create their own version of Zoom called UNSW BroomBroom or ‘Brooms’ for short to allow students to collaborate over video calls (in a "room").

It is recommended that you work on each of the questions below in order, but you can skip ahead if you wish. This question will be automarked, so make sure you follow any and all instructions relating to the type or structure of the data you need to accept as input or return as output.

#### 13.1. Backend (10 marks)

In `brooms.py` there is an incomplete series of functions for implementing this system. Implement these functions so that they match the documentation provided in `brooms.py`. This will be automarked, so ensure that your functions meet the specifications. Do NOT add additional arguments to the functions or rename them.

Partial marks are available for only implementing some of the functions.

#### 13.2. Testing (10 marks)

In `brooms_test.py` there is one simple test. In this file, write further tests to ensure that your implementation in `brooms.py` is correct.

For marking, your tests will be run against implementations other than your own, so they should make no assumptions about how the functions work beyond what is in their documentation and the documentation at the top of `brooms.py`. To get full marks, your tests should have 100% branch-coverage for your implementation.

To run your tests you can run `pytest brooms_test.py`.

To run coverage you can run `coverage run -m pytest brooms_test.py` followed by `coverage report`.

#### 13.3. Flask (10 marks)

In `server.py` implement a flask wrapper for the question asking service. The endpoints are described in comments in the file.

You can run your server with:
```bash
python3 server.py
```

Please use `APP.run(debug=True, port=8080)` when you finally submit. The automarking will use port 8080 to run your servers.

_If you are running on VLAB there is a port in use error, you may need to change the port from 8080 to something else. *REMEMBER TO SET THE PORT BACK TO 8080 BEFORE SUBMITTING!*_

To ensure it works as expected, use an API client to send the server requests.

When implementing the server:
 * In terms of return values, all routes should return a JSON string (jsonified python object).
 * In terms of input values, GET routes should get their arguments from `request.args` and POST/PUT/DELETE should get their arguments from `request.get_json()`.
 * We don't expect you to add any functionality to handle exceptions

Note that marks for this question are based on whether your server behaves in the same way as your backend implementation, so it is still possible to get full marks even if your backend does not meet the specifications in their entirety. Partial marks are also available for only implementing some endpoints.

<br />

### Question 14 (20 marks)

#### Part A (15 marks)

Inside `decorators_part_a.py`, complete the decorator `suffix_message`, which given a function, will call the function and append a string to the result string. The concatenated string should contain `", Suffix: "` + the **first argument passed in to the function**. For example:

```python
@suffix_message
def show_weather(weather):
    return 'The weather is ' + weather + ' today'

show_weather('raining') # ==> 'The weather is raining today, Suffix: raining'
```

If the function passed into the decorator does not take in any arguments then no suffix should be returned. There are tests provided for you which covers this case.

You can assume that:
* All functions passed in to the decorator will return a string;
* We will not test any functions that involve keyword arguments (`kwargs`).

A complete suite of tests has been provided for you in `decorator_part_a_test.py`. You do not need to write any tests for this question.

#### Part B (5 marks)

_You may find this part of the question challenging. We suggest you only complete it once you have completed all other parts of the exam._

In this part, you will be writing a decorator: `prefix_with`. The decorator accepts either a string, or another function which returns a string, to be decorated.

Here is an example of the `prefix_with` decorator being used:

```python
def say_hi():
    return 'hi'

@prefix_with(say_hi)
def show_weather_v2(message, weather):
    return f'{message}! Today, the weather is {weather}'

show_weather_v2('raining') # ==> 'hi! Today, the weather is raining'
```

The outer function allows us to pass in arguments to the inner decorator, which in this case is the function to run, or simply the string to use as the prefix.

In `decorators_part_b.py`, write a decorator named `prefix_with` so that:

* If `argument` is a function, run the function `argument` and then pass the return value of `argument` as an argument to the function that is being decorated. In this case the `argument` is `say_hi` and the function being decorated is `show_weather_v2`.
* If `argument` is a string, pass the value `argument` as an argument to the function that is being decorated

You can assume that:
* Any functions passed in as the decorator argument will themselves never take in any arguments; and
* Only strings or functions will be passed as arguments to prefix_with.

A complete suite of tests has been provided for you in `decorator_part_b_test.py`. You do not need to write any tests for this question.

## End of Exam 🎉🎉🎉

## Submission

Make sure you push your work to the master branch regularly. At the end of your specified exam time, we will automatically collect the code on your `master` branch's HEAD (i.e. latest commit). If you have changed the `server.py` port, make sure you change it back to `8080`, with: `APP.run(debug=True, port=8080)`.

Please note: If you develop locally ensure you check that your code works on the CSE servers. Failure to do so could result in a fail mark in the exam.

## Originality of Work

The work you submit must be your own work. Submission of work partially or completely derived from any other person or jointly written with any other person is not permitted.

The penalties for such an offence may include negative marks, automatic failure of the course and possibly other academic discipline. Exam submissions will be examined both automatically and manually for such submissions.

Relevant scholarship authorities will be informed if students holding scholarships are involved in an incident of plagiarism or other misconduct.

Do not provide or show your exam work to any other person apart from the teaching staff of COMP1531.

If you knowingly provide or show your exam work to another person for any reason, and work derived from it is submitted, you may be penalized, even if the work was submitted without your knowledge or consent.  This may apply even if your work is submitted by a third party unknown to you.

Note you will not be penalized if your work has the potential to be taken without your consent or knowledge.


import requests
from src import config


def test_dm_remove():
    # clear
    assert requests.delete(config.url+'clear/v1').status_code == 200

    # register owner1
    resp = requests.post(config.url + 'auth/register/v2', json={
        'email': 'one@mail.com',
        'password': 'abc123',
        'name_first': 'one',
        'name_last': 'one',
    })
    assert resp.status_code == 200
    owner1 = resp.json()

    # register member1
    resp = requests.post(config.url + 'auth/register/v2', json={
        'email': 'two@mail.com',
        'password': 'abc123',
        'name_first': 'two',
        'name_last': 'two',
    })
    assert resp.status_code == 200
    member1 = resp.json()

    # create dm1
    resp = requests.post(config.url + 'dm/create/v1', json={
        'token': owner1['token'],
        'u_ids': [member1['auth_user_id']],
    })
    assert resp.status_code == 200
    dm = resp.json()

    # leave dm1
    resp = requests.delete(config.url + 'dm/remove/v1', json={
        'token': owner1['token'],
        'dm_id': dm['dm_id'],
    })
    assert resp.status_code == 200


def test_dm_remove_invalid_token():
    # clear
    assert requests.delete(config.url+'clear/v1').status_code == 200

    # register owner1
    resp = requests.post(config.url + 'auth/register/v2', json={
        'email': '1@mail.com',
        'password': 'abc123',
        'name_first': 'one',
        'name_last': 'one',
    })
    assert resp.status_code == 200
    owner1 = resp.json()

    # register member1
    resp = requests.post(config.url + 'auth/register/v2', json={
        'email': '2@gmail.com',
        'password': 'abc123',
        'name_first': 'two',
        'name_last': 'two',
    })
    assert resp.status_code == 200
    member1 = resp.json()

    # create dm1
    resp = requests.post(config.url + 'dm/create/v1', json={
        'token': owner1['token'],
        'u_ids': [member1['auth_user_id']],
    })
    assert resp.status_code == 200
    dm = resp.json()

    # leave dm1 with invalid token
    resp = requests.delete(config.url + 'dm/remove/v1', json={
        'token': 0,
        'dm_id': dm['dm_id'],
    })
    assert resp.status_code == 403

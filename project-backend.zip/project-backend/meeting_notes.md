﻿Notes

Time: 2/24

Zoom link :

<https://zoom.us/j/99842209199?pwd=a0p0aVVGL2N6N1FKWHRNQ09tcTlCZz09>

How long :90 mins(Sean was coming for 15mins)

what do we do: We learned and read about the Major project.

Our group decided to have two teams, the first with three people and the second with two people.

Assignment: The first group completed auth.py and channels.py and The second group completed channels.py

Time:2/28

Zoom link : <https://zoom.us/j/95297228040?pwd=UDhzUllTV25WM3IwTTloQ21KbjdVQT09>

How long :90 mins

What do we do: We are completing the registration, login function.


Time:3/4

Zoom link : <https://zoom.us/j/93829738715?pwd=TVN1ZUNnRXNMdXdndVphaW9qUm9yZz09>

How long: 120mins

What do we do: Discuss the functions of channels, divide the work to each group to complete the functions and write the tests.

Time：3/5

Zoom link : <https://zoom.us/j/91641059889?pwd=Y3UrK3E2MVpGRk9aNFJIUEVKYnhwQT09>

How long: 90mins

What do we do: Discuss the function of channel, divide the work to each group to complete the function and write the test.

Zhitao wrote the function of detail and test, Linbo wrote the function of message, and the rest of the functions were given to the three of them.



Time：3/6

Google meet link：

<https://meet.google.com/xye-hurw-owq>

<https://meet.google.com/zzr-rsss-kyp>

<https://meet.google.com/ddh-uphf-poi>

<https://meet.google.com/xoe-wzxx-iiq>

<https://meet.google.com/kqv-saxr-mtr>

How long: 5hours

What do we do :

We debug together and change the style through pylint. debug is a very painful and huge challenge。

'''
TODO Complete this file by following the instructions in the lab exercise.
'''

integers = [1, 2, 3, 4, 5]
integers.append(6)
sumint = 0

for interger in integers:
    sumint += interger
print(sumint)

print(sum(integers))


# integers = [1, 2, 3, 4, 5]
# integers.append(6)
# j = 0
# for x in integers:
#     j = j + x
# print(j)

# print(sum(integers))

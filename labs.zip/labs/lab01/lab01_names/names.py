'''
TODO Complete this file by following the instructions in the lab exercise.
'''
# Name: Jake
# So you call yourself Jake huh?

name = input()
print(f'So you call yourself {name} huh?')

# Name = input()
# print(f"Name: So you call yourself {Name} huh?")

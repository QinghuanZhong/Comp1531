'''
TODO Complete this file by following the instructions in the lab exercise.
'''

strings = ['This', 'list', 'is', 'now', 'all', 'together']
result = None
for string in strings:
    print(string)
    if result:
        result += ' ' + string
    else:
        result = string
print(result)


print(' '.join(strings))
# char

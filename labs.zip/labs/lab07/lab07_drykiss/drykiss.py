def drykiss(my_list):
    # find the min
    '''
    my_min = 999999
    for i in range(0, 5):
        if my_list[i] < my_min:
            my_min = my_list[i]
    '''
    my_min = min(my_list)

    # multi 0 - 4 from the list
    '''
    product = 1
    for i in range(0, 4):
        product = product * my_list[i]
    result = product
    '''
    # multi 1-5 value from the list
    '''
    product = 1
    for i in range(1, 5):
        product = product * my_list[i]
    result = (my_min, result, product)
    return result
    '''
    # put above together
    product = 1
    for i in range(0, 5):
        product = product * my_list[i]
    result = product / my_list[4]
    product = product / my_list[0]

    result = (my_min, result, product)
    return result


if __name__ == '__main__':
    a = input("Enter a: ")
    a = int(a)
    b = input("Enter b: ")
    b = int(b)
    c = input("Enter c: ")
    c = int(c)
    d = input("Enter d: ")
    d = int(d)
    e = input("Enter e: ")
    e = int(e)
    my_list = [a, b, c, d, e]
    result = drykiss(my_list)
    print("Minimum: " + str(result[0]))
    print("Product of first 4 numbers: ")
    print(f"  {result[1]}")
    print("Product of last 4 numbers")
    print(f"  {result[2]}")

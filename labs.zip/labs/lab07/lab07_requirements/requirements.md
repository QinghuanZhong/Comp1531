me : client
teammate : engineer

Given, When, Then

cases: send direct message, see the image in the file

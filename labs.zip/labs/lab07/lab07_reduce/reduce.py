def reduce(f, xs):
    if len(xs) == 0:
        return None
    else:
        nList = xs[0]
        for element in xs[1:]:
            nList = f(nList, element)
        return nList


if __name__ == '__main__':
    print(reduce(lambda x, y: x + y, [1, 2, 3, 4, 5]))
    print(reduce(lambda x, y: x * y, [1, 2, 3, 4, 5]))

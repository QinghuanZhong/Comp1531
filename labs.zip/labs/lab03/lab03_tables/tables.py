import random


# solution


x = random.randint(2, 12)
y = random.randint(2, 12)


while True:
    print(f"What is ", x, " x ", y, "? ", sep='', end='')

    if int(input()) == (x * y):
        print("Correct!")
        break
    else:
        print("Incorrect - try again.")

'''
def time_table(randint):
    rand_1 = randint(2, 12)
    rand_2 = randint(2, 12)
    ans = x*y
    for x in rand_1:

        print("what is " + str(rand_1) "x" + str(rand_2) "?")
        for int in randint:
            if new.append
'''

'''
while True:
    ...

    if condition:
        break
'''

from wondrous import wondrous


def test_basic():
    assert wondrous(3) == [3, 10, 5.0, 16.0, 8.0, 4.0, 2.0, 1.0]


def test_number():
    assert wondrous(1) == [1]

'''file for woundrou.py'''


def wondrous(start):
    '''
    Returns the wondrous sequence for a given number.
    '''
    current = start
    sequence = []
    if start <= 1:
        return [start]

    while current != 1:
        sequence.append(current)
        if current % 2 == 0:
            # print(sequence)
            current /= 2
        else:
            current = (current * 3) + 1
    sequence.append(current)
    return sequence

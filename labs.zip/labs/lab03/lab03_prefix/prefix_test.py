'''test file for prefix'''
import pytest
from prefix import prefix_search


def test_documentation():
    '''test format'''
    assert prefix_search({"ac": 1, "ba": 2, "ab": 3}, "a") == {
        "ac": 1, "ab": 3}


def test_exact_match():
    '''test matching'''
    assert prefix_search({"category": "math", "cat": "animal"}, "cat") == {
        "category": "math", "cat": "animal"}


def test_invalid():
    '''invalid testing'''
    with pytest.raises(KeyError):
        prefix_search({"category": "math", "cat": "animal"}, "a")

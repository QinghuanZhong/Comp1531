I think most of team in our class are quit similar with us, however our team have better communication skill than other team as well as strong bond-connection.
I think i still prefer our function in project.
But other teams r perform great application in the group project, such as google meeting goole schedual etc.

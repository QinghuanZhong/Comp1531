
def check_password(password):
    '''
    Takes in a password, and returns a string based on the strength of that password.

    The returned value should be:
    * "Strong password", if at least 12 characters, contains at least one number, at least one uppercase letter, at least one lowercase letter.
    * "Moderate password", if at least 8 characters, contains at least one number.
    * "Poor password", for anything else
    * "Horrible password", if the user enters "password", "iloveyou", or "123456"
    '''
    char_upper = False
    char_lower = False
    char_num = False

    for char in password:
        if char.isnumeric():
            char_num = True
        if char.isupper():
            char_upper = True
        if char.islower():
            char_lower = True

    if password in ['password', 'iloveyou', '123456']:
        return 'Horrible password'
    if len(password) >= 12 and char_lower and char_upper and char_num:
        return 'Strong password'
    if len(password) >= 8 and char_num:
        return 'Moderate password'
    else:
        return 'Poor password'

    # if password is "password" or password is "iloveyou" or password is "123456":
    #     return "Horrible password"
    # length = 0
    # num = False
    # upper = False
    # lower = False

    # for x in password:
    #     if x.isupper():
    #         upper = True
    #     if x.islower():
    #         lower = True
    #     if x.isdigit():
    #         num = True
    #     length += 1

    # if length >= 12 and num and upper and lower:
    #     return "Strong password"
    # elif length >= 8 and num:
    #     return "Moderate password"
    # else:
    #     return "Poor password"


if __name__ == '__main__':
    print(check_password("ihearttrimesters"))
    # What does this do?
    # it's a guard, prevent access to somewhere else

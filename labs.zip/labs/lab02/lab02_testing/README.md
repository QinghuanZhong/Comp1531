## Lab02 - Exercise - Testing (Core)

This exercise will be started in the Week 2 tutorial. You are welcome to attempt it individually beforehand. 

### Group Activity

Open `password.py` and have a look at the function stub.

Brainstorm a list of tests for the function. Each test should cover one conceptual case / scenario / input. Complete a table which contains, for each test:

* Test name - which should describe what case is being tested;
* Parameters; and
* Return value.

### Individual Activity

Take 5 of the test cases your brainstormed and write them up in a new file called `password_test.py`. You will need to add the line `from password import check_password` in order to call the function to test.

<details>
<summary>Hints</summary>

* The `.isupper()` method allows to to test whether a string is uppercase
* The `.islower()` method allows to to test whether a string is lowercase
* The `.isnumeric()` method allows to to test whether a string is a substring of `'0123456789'`
* You can find the number of characters in a string using `len('my string')`.

</details>

Submit `password.py`, `password_test.py` and your brainstorming document by pushing to `master`.

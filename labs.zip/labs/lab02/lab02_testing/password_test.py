'''
Tests for check_password()
'''
from password import check_password

def test_horrible_password():
    assert check_password("iloveyou") == "Horrible password"
    assert check_password("abcdefg1") == "Moderate password"
    assert check_password("ABCdefghijklmnopqi123") == "Strong password"
    assert check_password("abcdefghijklmnopqi123") == "Moderate password"

    assert check_password(";.;.//;.;0") == "Moderate password"
    assert check_password("/;.;0") == "Poor password"
    assert check_password("-------------") == "Poor password"

## Lab02 - Exercise - Code Review (Core)

This exercise will be started in the Week 2 tutorial.

Review this piece of code, and inside `review.md`, answer the following questions:

1. What does it do?
2. What style could be improved here?
3. How can we change the code to be what we would describe as "pythonic"?

```python
x=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
result = []

for idx in range(len(x)):
  if x[idx] % 2 == 0:
    result.append(x[idx] * 2)
  else:
    result.append(x[idx])

print(result)
```

Once you have done this, make the necessary changes to improve the code.

The pipeline for this repository currently passes - it should stay that way, signalling that you haven't accidentally broken anything by changing the code.

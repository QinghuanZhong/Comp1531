x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# result = []

# for idx in range(len(x)):
#     if x[idx] % 2 == 0:
#         result.append(x[idx] * 2)
#     else:
#         result.append(x[idx])


result = [(num * 2 if num % 2 == 0 else num) for num in x]
print(result)

# what does it do? -> double even num.
# put the loop function in one line solution.

# result_test = [(num * 2 if num % 2 == 0 else num) for num in x]

# print(result_test)

from list_exercises import reverse_list, minimum, sum_list

def test_reverse():
    array = [1,2,3,4,5,6]
    reverse_list(array)
    assert array == [6,5,4,3,2,1] 

def test_reverse_2():
    # writing more test about reverse
    list_array = ["hi","are","you","okay"]
    reverse_list(list_array)
    assert list_array == ["okay","you","are","hi"]

def test_min_positive_numbers():
    assert minimum([23,12,45,24]) == 12

def test_min_positive_numbers_increase():                                                                                                                                                                             
    assert minimum([1,2,3]) == 1   

def test_min_positive_numbers_random():                                                                                                                                                                             
    assert minimum([2*2,23,5,6]) == 4
    assert minimum([12,34,5,6,41]) == 5

def test_sum_positive_numbers():
    assert sum_list([-3, -2, -1, 0, 1, 2, 3]) == 0

def test_sum_positive_numbers():
    assert sum_list([1,2,3,4,5,6,7,8,9,10]) == 55
    

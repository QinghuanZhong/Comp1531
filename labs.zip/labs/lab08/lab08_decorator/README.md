## Lab08 - Exercise - Decorator (Core)

Look at `decorator.py`. When you run it like the following:

```bash
python3 decorator.py CrocodileLikesStrawberries
```

The token `"CrocodileLikesStrawberries"` should you to interact with the functions.

Write a decorator to facilitate this authorisation. We have provided you with the stub and functions to be decorated - you simply need to implement the decorator itself. 

If the provided token is invalid, a `ValueError` should be raised by the `authorise` decorator.

```python
import sys

MESSAGE_LIST = []

@authorise
def get_messages():
    return MESSAGE_LIST

@authorise
def add_messages(msg):
    global MESSAGE_LIST
    MESSAGE_LIST.append(msg)

if __name__ == '__main__':
    auth_token = ""
    if len(sys.argv) == 2:
        auth_token = sys.argv[1]

    add_messages(auth_token, "Hello")
    add_messages(auth_token, "How")
    add_messages(auth_token, "Are")
    add_messages(auth_token, "You?")
    print(get_messages(auth_token))
```

You will also have to modify the code to ensure it is pylint compliant.


## Lab09 - Exercise - State (Core)

This exercise will be started in the tutorial.

Generate a state diagram to describe the states and subsequent transitions that would occur for a grocery store checkout system, from the perspective of the user-machine interaction.

Your tutor will give you the first state and transition to give you a starting point.

![](https://www.canstarblue.com.au/wp-content/uploads/2018/09/shutterstock_793003627-300x189.jpg)

Submit your diagram to this exercise in a file called `state` (can be of any format).

## Lab09 - Exercise - Deploy (Core)

Inside `server.py` is a solution to the [Tute 05 Flask Exercise](https://gitlab.cse.unsw.edu.au/COMP1531/22T1/content/-/tree/master/tutorials/tut05), with the accompanying backend logic in `names_ages.py`. There are a series of HTTP tests for the server in `server_test.py`.

Deploy this application using alwaysdata (in accordance with instructions from lectures) so that it can be accessed online from anywhere. You will need to research how to do this, create accounts, etc.

Once this is done, copy and paste the URL into the variable inside `server_test.py` and make sure that all the HTTP tests still pass.

Well done, you've deployed your first ever app to the internet!

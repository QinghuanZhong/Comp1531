from interleavings import interleavings

def test_documentation1():
    pass # assert interleavings('ab', 'cd') == ['abcd', 'acbd', 'acdb', 'cabd', 'cadb', 'cdab']

def test_documentation2():
    pass # assert interleavings('a', 'cd') == ['acd', 'cad', 'cda']

def test_single():
    pass # assert interleavings('a', 'b') == ['ab', 'ba']

def test_uneven():
    pass # assert interleavings('za','xy') == ['xyza', 'xzay', 'xzya', 'zaxy', 'zxay', 'zxya']

def test_uppercase():
    pass # assert interleavings('A', 'BCDE') == ['ABCDE', 'BACDE', 'BCADE', 'BCDAE', 'BCDEA']

def test_empty():
    pass # assert interleavings('','') == ['']

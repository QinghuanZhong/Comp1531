def interleavings(a, b):
    pass

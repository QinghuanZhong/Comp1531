## Lab04 - Exercise - Code Review (Core)

This exercise will be started in the Week 4 tutorial.

Your tutor will split you up into your project groups.

* [review_1.py](review_1.py)
* [review_2.py](review_2.py)

As a group, compare these two pieces of code from a pythonic, style, and readability point of view and choose which one you prefer, and making notes inside `review.md`. When you choose one, you must justify your reasoning inside `review.md`.

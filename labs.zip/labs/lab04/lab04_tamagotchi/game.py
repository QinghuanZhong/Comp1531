from tamagotchi import Tamagotchi

def play_tamagotchi(commands):
    pass

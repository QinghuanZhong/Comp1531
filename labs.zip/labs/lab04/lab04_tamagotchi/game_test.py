from game import play_tamagotchi

def check_output(commands, expected):
    with open(f'tests/{expected}') as expected_output:
        # Get rid of newlines in expected and actual to minimise annoying errors
        expected_output = expected_output.read().replace('\n', '')
        actual_output = play_tamagotchi(commands).replace('\n', '')

        assert actual_output == expected_output

def test_game0():
    pass
    """check_output(['create fluffy', 'wait', 'feed fluffy', 'play fluffy'], 'expected0.txt')"""

def test_game1():
    pass
    """check_output(['create fluffball', 'create fluffball', 'wait', 'wait',
                  'wait', 'wait', 'wait', 'wait', 'create fluffball'], 'expected1.txt')"""


def test_game2():
    pass
    """check_output(['feed buckbeak', 'create buckbeak', 'create norbert',
                  'create aragog', 'feed buckbeak', 'feed norbert', 'feed aragog',
                  'play buckbeak', 'feed buckbeak', 'feed buckbeak', 'feed aragog',
                  'play aragog', 'feed buckbeak', 'feed aragog', 'feed buckbeak',
                  'play aragog', 'feed buckbeak', 'play aragog', 'wait'], 'expected2.txt')"""

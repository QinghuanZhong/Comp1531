def draw(tree):
    pass

import primes

def test():
    pass

from flask import Flask, request
from json import dumps

APP = Flask(__name__)

nameList = []


def getNames():
    global nameList
    return nameList


@APP.route('/names/add', methods=['POST'])
def post():
    data = getNames()
    data.append(request.form.get('name'))
    return dumps({})


@APP.route('/names', methods=['GET'])
def get():
    data = getNames()
    return dumps({
        'nameList': data,
    })


@APP.route('/names/remove', methods=['DELETE'])
def remove():
    data = getNames()
    data.remove(request.form.get('name'))
    return dumps({})


@APP.route('/names/clear', methods=['DELETE'])
def clear():
    data = getNames()
    data.remove(request.form.clear('name'))
    return dumps({})


if __name__ == '__main__':
    APP.run(port=5000)

## Lab05 - Exercise - Unpickle (Core)

### Part 1 - Pickle

A pickled file with data in it is stored in `shapecolour.p`. Write a function `most_common` inside program `unpickle.py` that un-pickles this file, and analyses the data to returns what the most common shape-colour pair is.

The return value of `unpickle.py` should be (for example, if the most common dictionary pair is red circle) the dictionary:

```python
{
    "colour": "red",
    "shape": "circle"
}
```

### Part 2 - JSON

In `process.py`, take the result from the shape colour data structure and store it in a bigger data structure:

```json
{
    "mostCommon" : {
        "colour" : "[most-common-colour]",
        "shape" : "[most-common-shape]"
    },
    "rawData" : [insert-raw-data-from-shapecolour.p]
}
```

[Items in brackets] should be replaced with actual values or data structures.

Write a function `process` inside file `process.py` that creates this new data structure, then outputs it as JSON to a file `processed.json`.

Ensure all your code is pylint compliant.

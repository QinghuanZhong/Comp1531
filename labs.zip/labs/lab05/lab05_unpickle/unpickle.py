import pickle
import operator

array = {}


def most_common():
    data = pickle.load(open("shapecolour.p", "rb"))

    for d in data:
        key = (d['colour'], d['shape'])
        if key not in array:
            array[key] = 0
        array[key] = array[key] + 1
    colour, shape = max(array.items(), key=operator.itemgetter(1))[0]

    return {
        "Colour": colour,
        "Shape": shape,
    }

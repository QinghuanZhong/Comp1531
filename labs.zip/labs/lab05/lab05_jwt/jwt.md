header :
{
"alg": "HS256",
"typ": "JWT"
}
PAYLOAD:DATA
{
"u_id": "12345"
}
VERIFY SIGNATURE

HMACSHA256(
base64UrlEncode(header) + "." +
base64UrlEncode(payload),

your-256-bit-secret

)
